const sql = require('mssql');
const config = {
    user: 'Mystivate',
    password: 'Myst1vate01!',
    server: 'mystivate.database.windows.net', // You can use 'localhost\\instance' to connect to named instance
    database: 'Mystivate_db',

    options: {
        encrypt: true // Use this if you're on Windows Azure
    }
}
async function main() {
    try {
        let pool = await sql.connect(config);
        let result = await pool.request().execute('usp_ScheduledDailyTasks');
        console.log(result);
        process.exit();
    } catch (err) {
        console.log(err);
    }
}

main();

sql.on('error', err => {
    console.log(err);
});